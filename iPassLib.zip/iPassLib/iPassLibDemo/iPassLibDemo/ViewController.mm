//
//  ViewController.m
//  iPassLibDemo
//
//  Created by 张元科 on 2018/6/28.
//  Copyright © 2018年 SDJG. All rights reserved.
//

#import "ViewController.h"
#import "RSA/IPassRSA.h"
#import "Hash/NSString+IPassHash.h"
#import "AES/NSData+IPassAES.h"
#import "iPassSecure.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    
    [iPassSecure sharedSecure];
    
    NSArray *temp =  [[iPassSecure sharedSecure] getAllData];
    iPassSecureData *item = [[iPassSecureData alloc] init];
    item.state = 0;
    item.level = 1;
    item.type = 0;
    item.content = @"中国银行123456中国银行123456中国银行123456中国银行123456中国银行123456中国银行123456中国银行123456中国银行123456中国银行123456中国银行123456中国银行123456中国银行123456";
    item.account = @"中国银行123456中国银行123456中国银行123456中国银行123456中国银行123456中国银行123456中国银行123456中国银行123456中国银行123456中国银行123456中国银行123456中国银行123456";
    item.password = @"中国银行中国银行中国银行中国银行中国银行中国银行";
    
//    if ([[iPassSecure sharedSecure] insertItem:item]) {
//        NSLog(@"插入成功");
//    } else {
//        NSLog(@"插入失败");
//    }
    
    
//    if ([[iPassSecure sharedSecure] checkPassword:@"99887788"]) {
//        NSLog(@"一样");
//    } else {
//        NSLog(@"不一样");
//    }
//    [[iPassSecure sharedSecure] setupLoginPass:@"99887788"];
//    [[iPassSecure sharedSecure] checkPassword:@"1234"];
//    [self deRSA:@"fRpEm6XApY+rSM5IRdJskJ3t+VR7wsQVkze5MunvwGW+OQ494iEiE1f+jJhR0BjguJh2mc8y32DZY51RqjnLks4lqy3/YF5bMA6zNDlo5IBGKtiZPo4Hfh/uQuiFCzjBD7yAiu5P2Jf8xC/c1pac2CvaOp6UNFxsvag0185B5aI="];
//    [self AESTest];
}


- (void)AESTest {
    NSString *key = @"abcdefgdddd";
    NSString *content = @"abcd12345";
    NSData *data = [content dataUsingEncoding:NSUTF8StringEncoding];
    NSData *temp = [data iPassAES256EncryptWithKey:key];
    
//    NSString *ff =  base64_encode_data_ipass(temp);
//    NSLog(@"dddddd:%@",ff);
//    temp = base64_decode_ipass(ff);
//
    NSData *de = [temp iPassAES256DecryptWithKey:key];
    
    NSLog(@"解密：\n%@",[[NSString alloc] initWithData:de encoding:NSUTF8StringEncoding]);
}

- (void)md5Test
{
    NSString *ddd = @"ab";
    NSString *h = [ddd md5String_iPass];
    NSLog(@"%@",h);
}

- (void)deRSA:(NSString *)content {
    NSString *path2 = [[NSBundle mainBundle] pathForResource:@"private_key" ofType:nil];
    NSData *data2 = [NSData dataWithContentsOfFile:path2];
    NSString *str2  = [[NSString alloc] initWithData:data2 encoding:NSDataBase64DecodingIgnoreUnknownCharacters];
    
    NSString *de = [IPassRSA decryptString:content privateKey:str2];
    NSLog(@"解密结果:\n%@",de);
}

- (void)RSATest {
    NSString *path = [[NSBundle mainBundle] pathForResource:@"pub_key" ofType:nil];
    NSData *data = [NSData dataWithContentsOfFile:path];
    NSString *str  = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    NSLog(@"pub key:\n%@",str);
    
    NSString *ss = [IPassRSA encryptString:@"abcdef" publicKey:str];
    NSLog(@"en:%@",ss);
    
    NSString *path2 = [[NSBundle mainBundle] pathForResource:@"private_key" ofType:nil];
    NSData *data2 = [NSData dataWithContentsOfFile:path2];
    NSString *str2  = [[NSString alloc] initWithData:data2 encoding:NSDataBase64DecodingIgnoreUnknownCharacters];
    NSLog(@"private key:\n%@",str2);
    
    
    NSString *de = [IPassRSA decryptString:ss privateKey:str2];
    NSLog(@"de:%@",de);
}


@end
