//
//  iPassSecure.m
//  iPassSecure
//
//  Created by 张元科 on 2018/6/28.
//  Copyright © 2018年 SDJG. All rights reserved.
//

#import "iPassSecure.h"
#import "NSData+IPassAES.h"
#include "RSA/IPassRSA.h"

#define IPassFileName @"iPass.data"
#define IPassKey @"$%^i#P#A#S#S23"

#ifndef __IPASS_DATA_
#define __IPASS_DATA_
typedef struct _iPassData {
    int index;
    int level;
    int type;// 类型
    int state;// 0可用，-1不可用
    int reserveds[16];// 备用
    char content[256];
    char account[256];
    char password[256];
}iPassData;

#endif

static NSString *base64_encode_data_ipass(NSData *data){
    data = [data base64EncodedDataWithOptions:0];
    NSString *ret = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    return ret;
}

static NSData *base64_decode_ipass(NSString *str){
    NSData *data = [[NSData alloc] initWithBase64EncodedString:str options:NSDataBase64DecodingIgnoreUnknownCharacters];
    return data;
}

/*iPassSecureData*/

@implementation iPassSecureData

@end

/*iPassSecure*/
@interface iPassSecure()
{
    NSString *_encr_key;
}
@property (nonatomic, assign) NSUInteger count;
@property (nonatomic, strong) NSMutableArray *ipassdatas;
@property (nonatomic, copy)   NSString *ipassPath;
@property (nonatomic, assign) BOOL hasSetupPassword;
@property (nonatomic, strong)   NSData *secPassData;// 加密
@property (nonatomic, assign) long long startOffset;
@property (nonatomic, strong) NSLock *lock;

@end

@implementation iPassSecure

+ (iPassSecure *)sharedSecure
{
    static id instance;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^ {
        instance = [[self alloc] init];
    });
    
    return instance;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        _lock = [[NSLock alloc] init];
        _count = 0;
        _hasSetupPassword = NO;
        _startOffset = 0;
        _encr_key = IPassKey;
        _ipassdatas = [[NSMutableArray alloc] init];
        [self checkFileData];
    }
    return self;
}

- (void)checkFileData {
    NSString *homePath = NSHomeDirectory();
    NSString *filePath = [NSString stringWithFormat:@"%@/Documents/%@",homePath,IPassFileName];
    _ipassPath = filePath;
    if (![[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
        // 不存在
        [[NSFileManager defaultManager] createFileAtPath:filePath contents:nil attributes:nil];
        [self setupFile:filePath];
    } else {
        [self loadPassData:filePath];
    }
}
// 第一次设置
- (void)setupFile:(NSString *)filePath {
    NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:filePath];
    NSData *header = [@"iPassword " dataUsingEncoding:NSUTF8StringEncoding]; // 10
    [fh writeData:header];
    [fh closeFile];
}
// 读取当前文件密码
- (void)loadPassData:(NSString *)filePath {
    if ([self isSetupPass]) {
        [self readPassData];
        [self getPassData];
    }
}

- (BOOL)isSetupPass {
    if (_hasSetupPassword) {
        return YES;
    }
    [_lock lock];
    NSFileHandle *fh = [NSFileHandle fileHandleForUpdatingAtPath:_ipassPath];
    [fh seekToFileOffset:9];
    NSData * data = [fh readDataOfLength:1];
    BOOL flag = NO;
    if (data != NULL) {
        Byte *by = (Byte *)data.bytes;
        if (by != NULL) {
            if (*by == 99) {
                // 设置过
                flag = YES;
                _hasSetupPassword = YES;
            }
        }
    }
    [fh closeFile];
    [_lock unlock];
    return flag;
}
- (void)readPassData {
    [_lock lock];
    NSFileHandle *fh = [NSFileHandle fileHandleForUpdatingAtPath:_ipassPath];
    [fh seekToFileOffset:10];
    NSData *data = [fh readDataOfLength:sizeof(NSUInteger)];
    NSUInteger length = 0;
    if (data != NULL) {
        memcpy(&length, data.bytes, sizeof(NSUInteger));
        if (length > 0) {
            data = [fh readDataOfLength:length];
            if (data != NULL) {
                _secPassData = data;
                //
                NSData *tempData = [data iPassAES256DecryptWithKey:IPassKey];
                _encr_key = [NSString stringWithFormat:@"%@%@",IPassKey,[[NSString alloc] initWithData:tempData encoding:NSUTF8StringEncoding]];
            }
        }
    }
    [fh closeFile];
    [_lock unlock];
}

- (void)getPassData {
    [_lock lock];
    NSFileHandle *fh = [NSFileHandle fileHandleForReadingAtPath:_ipassPath];
    [fh seekToEndOfFile];
    long long offset = fh.offsetInFile;
    long long iPassLength = sizeof(iPassData);
    long long startOffset = offset % iPassLength;
    self.startOffset = startOffset;// 214
    // 当前个数
    int count = (int)(offset - startOffset) / iPassLength;
    self.count = count;
    for (int i = 0; i < count; i++) {
        [fh seekToFileOffset:self.startOffset + i * sizeof(iPassData) ];
        NSData *tempData = [fh readDataOfLength:sizeof(iPassData)];
        if (tempData != NULL) {
            iPassData *pass = (iPassData *)malloc(sizeof(iPassData));
            memcpy(pass, tempData.bytes, sizeof(iPassData));
            iPassSecureData *secureData = [[iPassSecureData alloc] init];
            [self convertiPassData:pass toSecureData:secureData];
            [self.ipassdatas addObject:secureData];
            free(pass);
        }
    }
    [fh closeFile];
    [_lock unlock];
}


// 密码只能设置一次
- (BOOL)setupLoginPass:(NSString *)pass {
    if ([self isSetupPass]) {
        return NO;
    }
    [_lock lock];
    if (pass.length >= 4 && pass.length <= 8) {
        NSString *key = IPassKey;
        NSString *content = pass;
        _encr_key = [NSString stringWithFormat:@"%@%@",IPassKey,content];
        NSData *data = [content dataUsingEncoding:NSUTF8StringEncoding];
        NSData *encrypt = [data iPassAES256EncryptWithKey:key];
        _secPassData = encrypt;
        NSUInteger count = encrypt.length;
        NSMutableData *countData = [NSMutableData dataWithBytes:&count length:sizeof(count)];
        [countData appendData:encrypt];
        // AES加密
        
        NSFileHandle *fh = [NSFileHandle fileHandleForUpdatingAtPath:_ipassPath];
        [fh seekToFileOffset:10];
        [fh writeData:countData];
        
        // RSA
        content = pass;
        
        NSString *pub_key_path = [[NSBundle mainBundle] pathForResource:@"pub_key" ofType:nil];
        NSData *pub_data = [NSData dataWithContentsOfFile:pub_key_path];
        NSString *pub_key  = [[NSString alloc] initWithData:pub_data encoding:NSUTF8StringEncoding];
        
        NSString *encrypt_rsa = [IPassRSA encryptString:content publicKey:pub_key];
        encrypt = [encrypt_rsa dataUsingEncoding:NSUTF8StringEncoding];
        
        if ([encrypt length] > 0) {
            count = encrypt.length;
            countData = [NSMutableData dataWithBytes:&count length:sizeof(count)];
            [countData appendData:encrypt];
            // RSA加密
            [fh writeData:countData];
            // 写入标志
            Byte flag = 99;
            [fh seekToFileOffset:9];
            data = [NSData dataWithBytes:&flag length:1];
            [fh writeData:data];
            [fh closeFile];
            _hasSetupPassword = YES;
            [_lock unlock];
            return YES;
        }
        [fh closeFile];
    }
    [_lock unlock];
    return NO;
}
// 校验密码是否正确（低等级）
- (BOOL)checkPassword:(NSString *)loginpass {
    BOOL flag = [self isSetupPass];
    if ([_secPassData length] > 0) {
        NSData *decrypt = [_secPassData iPassAES256DecryptWithKey:IPassKey];
        NSString *decryptStr = [[NSString alloc] initWithData:decrypt encoding:NSUTF8StringEncoding];
        if ([decryptStr isEqualToString:loginpass]) {
            return YES;
        }
    }
    if (flag) {
        // 读取
        [_lock lock];
        NSFileHandle *fh = [NSFileHandle fileHandleForUpdatingAtPath:_ipassPath];
        [fh seekToFileOffset:10];
        NSData *data = [fh readDataOfLength:sizeof(NSUInteger)];
        NSUInteger length = 0;
        if (data != NULL) {
            memcpy(&length, data.bytes, sizeof(NSUInteger));
            if (length > 0) {
                data = [fh readDataOfLength:length];
                if (data != NULL) {
                    NSData *decrypt = [data iPassAES256DecryptWithKey:IPassKey];
                    NSString *decryptStr = [[NSString alloc] initWithData:decrypt encoding:NSUTF8StringEncoding];
                    if ([decryptStr isEqualToString:loginpass]) {
                        [fh closeFile];
                        [_lock unlock];
                        return YES;
                    }
                }
            }
        }
        [fh closeFile];
        [_lock unlock];
    }
    
    return NO;
}

- (void)convertiPassData:(iPassData *)pass toSecureData:(iPassSecureData *)item {
    item.index = pass->index;
    item.level = pass->level;
    item.type = pass->type;
    item.state = pass->state;
    if (strlen(pass->content) > 0) {
        NSData *data = [NSData dataWithBytes:pass->content length:strlen(pass->content)];
        NSString *str = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        item.content = str;
    }
    if (strlen(pass->account) > 0) {
        NSData *data = [NSData dataWithBytes:pass->account length:strlen(pass->account)];
        NSString *str = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        item.account = str;
    }
    if (strlen(pass->password) > 0) {
        NSData *data = [NSData dataWithBytes:pass->password length:strlen(pass->password)];
        NSString *str = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        NSData *tempData = base64_decode_ipass(str);
        NSData *temp = [tempData iPassAES256DecryptWithKey:_encr_key];
        item.password = [[NSString alloc] initWithData:temp encoding:NSUTF8StringEncoding];
    }
}
    
- (void)convertSecureData:(iPassSecureData *)item toiPassData:(iPassData *)pass {
    pass->index = item.index;
    pass->level = item.level;
    pass->type = item.type;
    pass->state = item.state;
    if ([item.content length] > 0) {
        NSData *wData = [item.content dataUsingEncoding:NSUTF8StringEncoding];
        if (wData != NULL && wData.bytes != NULL) {
            memcpy(pass->content, wData.bytes, wData.length);
        }
    }
    if ([item.account length] > 0) {
        NSData *wData = [item.account dataUsingEncoding:NSUTF8StringEncoding];
        if (wData != NULL && wData.bytes != NULL) {
            memcpy(pass->account, wData.bytes, wData.length);
        }
    }
    if ([item.password length] > 0) {
        // 加密
        NSData *data = [item.password dataUsingEncoding:NSUTF8StringEncoding];
        NSData *temp = [data iPassAES256EncryptWithKey:_encr_key];
        NSString *encode = base64_encode_data_ipass(temp);
        NSData *wData = [encode dataUsingEncoding:NSUTF8StringEncoding];
        if (wData != NULL && wData.bytes != NULL) {
            memcpy(pass->password, wData.bytes, wData.length);
        }
    }
}

- (BOOL)insertItem:(iPassSecureData *)item {
    [_lock lock];
    iPassData *pass = ( iPassData *)malloc(sizeof(iPassData));
    memset(pass, 0, sizeof(iPassData));
    item.index = (int)self.count;// 是可以计算出文件位置的，从0开始计算
    self.count++;
    [self convertSecureData:item toiPassData:pass];
    NSFileHandle *fh = [NSFileHandle fileHandleForUpdatingAtPath:_ipassPath];
    [fh seekToEndOfFile];
    NSData *passData = [NSData dataWithBytes:pass length:sizeof(iPassData)];
    [fh writeData:passData];
    [fh closeFile];
    free(pass);
    [_ipassdatas addObject:item];
    [_lock unlock];
    return YES;
}
- (BOOL)updateItem:(iPassSecureData *)item {
    [_lock lock];
    if (item.index < self.count && item.index >= 0 && item.index < self.ipassdatas.count) {
        iPassData *pass = ( iPassData *)malloc(sizeof(iPassData));
        memset(pass, 0, sizeof(iPassData));
        [self convertSecureData:item toiPassData:pass];
        NSFileHandle *fh = [NSFileHandle fileHandleForUpdatingAtPath:_ipassPath];
        [fh seekToFileOffset:self.startOffset + item.index * sizeof(iPassData)];
        NSData *passData = [NSData dataWithBytes:pass length:sizeof(iPassData)];
        [fh writeData:passData];
        [fh closeFile];
        free(pass);
        self.ipassdatas[item.index] = item;
        [_lock unlock];
        return YES;
    }
    [_lock unlock];
    return NO;
}
- (BOOL)deleteItem:(iPassSecureData *)item {
    [_lock lock];
    if (item.index < self.count && item.index >= 0 && item.index < self.ipassdatas.count) {
        item.state = -1;
        iPassData *pass = ( iPassData *)malloc(sizeof(iPassData));
        memset(pass, 0, sizeof(iPassData));
        [self convertSecureData:item toiPassData:pass];
        NSFileHandle *fh = [NSFileHandle fileHandleForUpdatingAtPath:_ipassPath];
        [fh seekToFileOffset:self.startOffset + item.index * sizeof(iPassData)];
        NSData *passData = [NSData dataWithBytes:pass length:sizeof(iPassData)];
        [fh writeData:passData];
        [fh closeFile];
        free(pass);
        self.ipassdatas[item.index] = item;
        [_lock unlock];
        return YES;
    }
    [_lock unlock];
    return NO;
}
- (NSArray<iPassSecureData *> *)getAllData {
    return [_ipassdatas copy];
}

@end
