//
//  iUnPassLib.h
//  iUnPassLib
//
//  Created by 张元科 on 2018/6/28.
//  Copyright © 2018年 SDJG. All rights reserved.
//

#import <Foundation/Foundation.h>
// 独立的解密功能
@interface iUnPassLib : NSObject

@end
