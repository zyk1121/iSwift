// TEST_CFLAGS -framework Foundation
// TEST_CONFIG GC=0

#define FOUNDATION 1
#define NAME "rr-nsautorelease"

#include "rr-autorelease2.m"
