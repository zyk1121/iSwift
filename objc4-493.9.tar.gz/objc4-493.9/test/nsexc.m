// TEST_CFLAGS -framework Foundation

#define USE_FOUNDATION 1
#include "exc.m"
