//
//  ViewController.swift
//  iTestImage
//
//  Created by 张元科 on 2018/7/3.
//  Copyright © 2018年 SDJG. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.white
        setupData()
        OCTest()
        testMemLeak()
    }
    
    func OCTest()
    {
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 15.0) {
            let vc = ViewController2()
            self.present(vc, animated: true) {
                
            }
        }
    }
    
    func testMemLeak()
    {
        for i in 0...1000 {
            let image = UIImage(named:"image2.jpg")
            self.imageView2.image = image;
            let color = YKImageToolsSwift.getImageColor(image)
            
            let tempImage = YKImageToolsSwift.createImage(with: color)
        }
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        let vc = ViewController2()
        self.present(vc, animated: true) {
            
        }
    }

    var scroolView = UIScrollView()
    var imageView1 = UIImageView()
    var imageView2 = UIImageView()
    // 开始
    func setupData() {
        scroolView = UIScrollView(frame: UIScreen.main.bounds)
        self.view.addSubview(scroolView)
        scroolView.contentSize = CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height + 1)
        
        
        self.view.addSubview(scroolView)
        imageView1 = UIImageView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 300))
        self.scroolView.addSubview(imageView1)
        imageView2 = UIImageView(frame: CGRect(x: 0, y: 300, width: UIScreen.main.bounds.width, height: 390))
        self.scroolView.addSubview(imageView2)
        
        let image = UIImage(named:"image2.jpg")
        self.imageView2.image = image;
        let color = YKImageToolsSwift.getImageColor(image)
        
        let tempImage = YKImageToolsSwift.createImage(with: color)
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2.0) {
            self.imageView1.image = tempImage
        }
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 5.0) {
            if let layer = YKImageToolsSwift.getGradientLayer(with: color, andFrame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 50)) {
                self.imageView2.layer.addSublayer(layer)
            }
        }
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 10.0) {
             self.scroolView.backgroundColor = color
        }
    }
}

// 模仿微信朋友圈背景图下拉效果
class YKImageToolsSwift {
    //  The converted code is limited to 4 KB.
    //  Upgrade your plan to remove this limitation.
    //
    //  Converted to Swift 4 by Swiftify v4.1.6751 - https://objectivec2swift.com/
    
    /* 用于生成渐变色，添加到图片的顶部，frame需要自定义 */
    class func getGradientLayer(with color: UIColor?, andFrame frame: CGRect) -> CAGradientLayer? {
        if color != nil {
            var alpha: CGFloat = 0
            var red: CGFloat = 0
            var green: CGFloat = 0
            var blue: CGFloat = 0
            color?.getRed(&red, green: &green, blue: &blue, alpha: &alpha)
            let layer = CAGradientLayer()
            layer.colors = [UIColor(red: red, green: green, blue: blue, alpha: alpha).cgColor, UIColor(red: red, green: green, blue: blue, alpha: 0.0).cgColor]
            layer.startPoint = CGPoint(x: 0.0, y: 0.0)
            layer.endPoint = CGPoint(x: 0.0, y: 1.0)
            layer.frame = frame
            return layer
        }
        return nil
    }
    
    /* 获取当前图像第一行的像素均值 */
    class func getImageColor(_ image: UIImage?) -> UIColor? {
        var color: UIColor? = nil
        let inImage = image?.cgImage
        if inImage == nil {
            return nil
        }
        // Create off screen bitmap context to draw the image into. Format ARGB is 4 bytes for each pixel: Alpa, Red, Green, Blue
        let cgctx = self.createARGBBitmapContext(fromImage: inImage)
        if cgctx == nil {
            return color
        }
        let w = inImage!.width
        let h = inImage!.height
        let rect = CGRect(x: 0, y: 0, width: w, height: h)
        if w <= 0 || h <= 0 {
            return color
        }
        // Draw the image to the bitmap context. Once we draw, the memory
        // allocated for the context for rendering will then contain the
        // raw image data in the specified color space.
        cgctx?.draw(inImage!, in: rect)
        // Now we can get a pointer to the image data associated with the bitmap
        // context.
        let tempData = cgctx?.data
        let data = tempData?.bindMemory(to: UInt8.self, capacity: w * 4)
        if data != nil {
            //offset locates the pixel in the data from x,y.
            //4 for 4 bytes of data per pixel, w is width of one row of data.
            var alpha: Int  = 0
            var red: Int    = 0
            var green: Int  = 0
            var blue: Int   = 0
            // 取第一行的数据
            for i in 0..<w {
                let offset = Int(4 * i)
                alpha   += Int(data!.advanced(by: offset).pointee)
                red     += Int(data!.advanced(by: offset + 1).pointee)
                green   += Int(data!.advanced(by: offset + 2).pointee)
                blue    += Int(data!.advanced(by: offset + 3).pointee)
            }
            alpha       = Int(alpha / w)
            red         = Int(red / w)
            green       = Int(green / w)
            blue        = Int(blue / w)
            color       = UIColor(red: CGFloat(red) / 255.0, green: CGFloat(green) / 255.0, blue: CGFloat(blue) / 255.0, alpha: CGFloat(alpha) / 255.0)
        }
        // When finished, release the context
        // Free image data memory for the context
        if data != nil {
            free(data)
        }
        return color
    }
    
    class func createImage(with color: UIColor?) -> UIImage? {
        let rect = CGRect(x: 0.0, y: 0.0, width: 1.0, height: 1.0)
        UIGraphicsBeginImageContext(rect.size)
        let context = UIGraphicsGetCurrentContext()
        context?.setFillColor((color?.cgColor)!)
        context?.fill(rect)
        let theImage: UIImage? = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return theImage
    }
    
    //  Converted to Swift 4 by Swiftify v4.1.6751 - https://objectivec2swift.com/
    class func createARGBBitmapContext(fromImage inImage: CGImage?) -> CGContext? {
        var context: CGContext? = nil
        if inImage == nil {
            return nil
        }
        var colorSpace: CGColorSpace?
        var bitmapData: UnsafeMutableRawPointer?
        var bitmapByteCount: Int
        var bitmapBytesPerRow: Int
        // Get image width, height. We'll use the entire image.
        let pixelsWide = inImage!.width
        let pixelsHigh = inImage!.height
        // Declare the number of bytes per row. Each pixel in the bitmap in this
        // example is represented by 4 bytes; 8 bits each of red, green, blue, and
        // alpha.
        bitmapBytesPerRow = Int(pixelsWide * 4)
        bitmapByteCount = Int(bitmapBytesPerRow * pixelsHigh)
        // Use the generic RGB color space.
        colorSpace = CGColorSpaceCreateDeviceRGB()
        if colorSpace == nil {
            return nil
        }
        // Allocate memory for image data. This is the destination in memory
        // where any drawing to the bitmap context will be rendered.
        bitmapData = malloc(bitmapByteCount)
        if bitmapData == nil {
            return nil
        }
        // Create the bitmap context. We want pre-multiplied ARGB, 8-bits
        // per component. Regardless of what the source image format is
        // (CMYK, Grayscale, and so on) it will be converted over to the format
        // specified here by CGBitmapContextCreate.
        context = CGContext(data: bitmapData, width: pixelsWide, height: pixelsHigh, bitsPerComponent: 8, bytesPerRow:     // bits per component
            bitmapBytesPerRow, space: colorSpace!, bitmapInfo: CGImageAlphaInfo.premultipliedFirst.rawValue)
        if context == nil {
            free(bitmapData)
        }
        // Make sure and release colorspace before returning
        
        return context
    }
}
