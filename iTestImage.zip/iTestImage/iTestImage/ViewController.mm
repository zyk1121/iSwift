//
//  ViewController.m
//  iTest
//
//  Created by 张元科 on 2018/6/8.
//  Copyright © 2018年 SDJG. All rights reserved.
//

#import "ViewController2.h"

@interface ViewController2 ()

@property (strong) UIScrollView *scroolView;
@property (strong) UIImageView *imageView1;
@property (strong) UIImageView *imageView2;

@end

@implementation ViewController2

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    _scroolView = [[UIScrollView alloc] initWithFrame:UIScreen.mainScreen.bounds];
    [self.view addSubview:_scroolView];
    _scroolView.contentSize = CGSizeMake(UIScreen.mainScreen.bounds.size.width, UIScreen.mainScreen.bounds.size.height + 1);
    
    _imageView1 = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, UIScreen.mainScreen.bounds.size.width, 300)];
    [self.scroolView addSubview:_imageView1];
    _imageView2 = [[UIImageView alloc] initWithFrame:CGRectMake(0, 300, UIScreen.mainScreen.bounds.size.width, 390)];
    [self.scroolView addSubview:_imageView2];
    
//    UIImage *image = [UIImage imageNamed:@"image1.jpg"];
    UIImage *image = [UIImage imageNamed:@"image2.jpg"];
    self.imageView2.image = image;
    UIColor *color = [YKImageToolsOC getImageColor:image];
    
    UIImage *tempImage = [YKImageToolsOC createImageWithColor:color];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        self.imageView1.image = tempImage;
    });
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        CAGradientLayer *layer = [YKImageToolsOC getGradientLayerWith:color andFrame:CGRectMake(0, 0, UIScreen.mainScreen.bounds.size.width, 50)];
        [self.imageView2.layer addSublayer:layer];
    });
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(10.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        self.scroolView.backgroundColor = color;
    });
}

@end


@implementation YKImageToolsOC

/* 用于生成渐变色，添加到图片的顶部，frame需要自定义 */
+ (CAGradientLayer *)getGradientLayerWith:(UIColor *)color andFrame:(CGRect)frame {
    if (color != NULL) {
        CGFloat alpha = 0;
        CGFloat red = 0;
        CGFloat green = 0;
        CGFloat blue = 0;
        [color getRed:&red green:&green blue:&blue alpha:&alpha];
        CAGradientLayer *layer = [CAGradientLayer layer];
        layer.colors = @[(__bridge id)[UIColor colorWithRed:red green:green blue:blue alpha:alpha].CGColor,(__bridge id)[UIColor colorWithRed:red green:green blue:blue alpha:0.0].CGColor];
        layer.startPoint = CGPointMake(0.0, 0.0);
        layer.endPoint = CGPointMake(0.0, 1.0);
        layer.frame = frame;
        return layer;
    }
    return NULL;
}

/* 获取当前图像第一行的像素均值 */
+ (UIColor *)getImageColor:(UIImage *)image {
    UIColor* color = NULL;
    CGImageRef inImage = image.CGImage;
    // Create off screen bitmap context to draw the image into. Format ARGB is 4 bytes for each pixel: Alpa, Red, Green, Blue
    CGContextRef cgctx = [self createARGBBitmapContextFromImage:inImage];
    if (cgctx == NULL) {
        CGContextRelease(cgctx);
        return color;
    }
    
    size_t w = CGImageGetWidth(inImage);
    size_t h = CGImageGetHeight(inImage);
    CGRect rect = {{0,0},{static_cast<CGFloat>(w),static_cast<CGFloat>(h)}};
    
    if (w <= 0 || h <= 0) {
        CGContextRelease(cgctx);
        return color;
    }
    
    // Draw the image to the bitmap context. Once we draw, the memory
    // allocated for the context for rendering will then contain the
    // raw image data in the specified color space.
    CGContextDrawImage(cgctx, rect, inImage);
    
    // Now we can get a pointer to the image data associated with the bitmap
    // context.
    unsigned char* data = (unsigned char *)CGBitmapContextGetData(cgctx);
    
    if (data != NULL) {
        //offset locates the pixel in the data from x,y.
        //4 for 4 bytes of data per pixel, w is width of one row of data.
        int alpha = 0;
        int red = 0;
        int green = 0;
        int blue = 0;
        // 取第一行的数据
        for (int i = 0; i < w; i++) {
            int offset = 4*((w*round(0))+round(i));
            alpha += data[offset];
            red += data[offset+1];
            green += data[offset+2];
            blue += data[offset+3];
        }
        alpha = alpha / w;
        red = red / w;
        green = green / w;
        blue = blue / w;
        
        color = [UIColor colorWithRed:(red/255.0f) green:(green/255.0f) blue:(blue/255.0f) alpha:(alpha/255.0f)];
    }
    
    // When finished, release the context
    CGContextRelease(cgctx);
    // Free image data memory for the context
    if (data) { free(data); }
    return color;
}

+ (UIImage *)createImageWithColor:(UIColor *)color
{
    CGRect rect = CGRectMake(0.0f, 0.0f, 1.0f, 1.0f);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *theImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return theImage;
}

+ (CGContextRef)createARGBBitmapContextFromImage:(CGImageRef)inImage {
    
    CGContextRef    context = NULL;
    CGColorSpaceRef colorSpace;
    void *          bitmapData;
    int             bitmapByteCount;
    int             bitmapBytesPerRow;
    
    // Get image width, height. We'll use the entire image.
    size_t pixelsWide = CGImageGetWidth(inImage);
    size_t pixelsHigh = CGImageGetHeight(inImage);
    
    // Declare the number of bytes per row. Each pixel in the bitmap in this
    // example is represented by 4 bytes; 8 bits each of red, green, blue, and
    // alpha.
    bitmapBytesPerRow   = (int)(pixelsWide * 4);
    bitmapByteCount     = (int)(bitmapBytesPerRow * pixelsHigh);
    
    // Use the generic RGB color space.
    colorSpace = CGColorSpaceCreateDeviceRGB();
    
    if (colorSpace == NULL)
    {
        return NULL;
    }
    
    // Allocate memory for image data. This is the destination in memory
    // where any drawing to the bitmap context will be rendered.
    bitmapData = malloc( bitmapByteCount );
    if (bitmapData == NULL)
    {
        CGColorSpaceRelease( colorSpace );
        return NULL;
    }
    
    // Create the bitmap context. We want pre-multiplied ARGB, 8-bits
    // per component. Regardless of what the source image format is
    // (CMYK, Grayscale, and so on) it will be converted over to the format
    // specified here by CGBitmapContextCreate.
    context = CGBitmapContextCreate (bitmapData,
                                     pixelsWide,
                                     pixelsHigh,
                                     8,      // bits per component
                                     bitmapBytesPerRow,
                                     colorSpace,
                                     kCGImageAlphaPremultipliedFirst);
    if (context == NULL)
    {
        free (bitmapData);
    }
    
    // Make sure and release colorspace before returning
    CGColorSpaceRelease( colorSpace );
    
    return context;
}

@end
