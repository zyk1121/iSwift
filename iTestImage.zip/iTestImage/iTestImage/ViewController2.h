//
//  ViewController.h
//  iTest
//
//  Created by 张元科 on 2018/6/8.
//  Copyright © 2018年 SDJG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController2 : UIViewController


@end


@interface YKImageToolsOC:NSObject

// 获取当前图像第一行的像素均值 : 色值Color
+ (UIColor *)getImageColor:(UIImage *)image;
// 根据色值生成对应的渐变色
+ (CAGradientLayer *)getGradientLayerWith:(UIColor *)color andFrame:(CGRect)frame;
// 根据设置生成图片UIImage
+ (UIImage *)createImageWithColor:(UIColor *)color;

@end
