//
//  RXNewBindUIViewController.swift
//  iTestProject
//
//  Created by 张元科 on 2017/12/6.
//  Copyright © 2017年 SDJG. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa

class RXNewBindUIViewController: UIViewController {

        var label:UILabel?
        var label2:UILabel?
        override func viewDidLoad() {
            super.viewDidLoad()
            
            view.backgroundColor = UIColor.white
            
            label = UILabel()
            label?.frame = CGRect(x: 0, y: 100, width: 200, height: 40)
            label?.text = "1"
            label?.textColor = UIColor.red
            view.addSubview(label!)
            
            
            label2 = UILabel()
            label2?.frame = CGRect(x: 0, y: 300, width: 200, height: 40)
            label2?.text = "2"
            label2?.textColor = UIColor.red
            view.addSubview(label2!)
            
//            test()
//            test2()
//            test3()
            
            test4()
        }
    
    var testObj =  TestObject()

    func test() {

        let stu = Student()
        testObj.stu = stu
        
//        testObj.rx.observe(String.self, "stu.name").subscribe { (event) in
//            //            print(event)
//            print(Thread.current)
//        }
        
        testObj.rx.observe(String.self, "stu.name").asDriver(onErrorJustReturn: "").asObservable().subscribe { (event) in
            
            print(Thread.current)
        }.addDisposableTo(disposeBag)
//        testObj.rx.observe(String.self, "stu.name").asObservable().bind(to: label!.rx.text).addDisposableTo(disposeBag)
        testObj.rx.observe(String.self, "stu.name").asObservable().bind(to: label2!.rx.text).addDisposableTo(disposeBag)

        
        testObj.rx.observe(String.self, "stu.name").asDriver(onErrorJustReturn: "").drive(label!.rx.text).addDisposableTo(disposeBag)
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1.0, execute: {
            self.testObj.stu?.name = "123"
        })
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 3.0, execute: {
            let sss = Student()
            sss.name = "haha"
            self.testObj.stu = sss
            self.testObj.stu?.name = "abc"
            //            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1.0, execute: {
            //                sss.name = "hhhhh"
            //            })
            DispatchQueue.global().asyncAfter(deadline: DispatchTime.now() + 1.0, execute: {
                sss.name = "hhhhh"
            })
        })
    }
    var testObj2 = TestObject()
    func test2()
    {
        let stu = Student()
        testObj2.stu = stu
        
        testObj2.rx.observeWeakly(String.self, "stu.name").asObservable().bind(to: label!.rx.text).addDisposableTo(disposeBag)
//        let sign = testObj2.rx.observe(String.self, "stu.name").map { (value) -> String in
//            return value ?? ""
//        }
        
//        bindTo(from: testObj2.rx.observeWeakly(String.self, "stu.name").asObservable(), to: label!.rx)
//        bindTo(from: testObj2.rx.observeWeakly(String.self, "stu.name").asObservable(), to: label!.rx)
//        bindTo(from: testObj2.rx.observeWeakly(String.self, "stu.name").asObservable(), to: label!.rx)
//        bindTo(from: testObj2.rx.observeWeakly(String.self, "stu.name").asObservable(), to: label!.rx.text)
//        bindTo(from: testObj2.rx.observeWeakly(String.self, "stu.name").asObservable(), to: label!.rx.text)
        //        disBag = nil
        //        disBag = DisposeBag()
        testObj2.rx.observe(String.self, "stu.name").asObservable().map { (str) -> String in
            if str != nil {
                let ss = str! + "123"
                return ss
            }
            return ""
            }.bind(to: label2!.rx.text).addDisposableTo(disposeBag)
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1.0, execute: {
            //            print(self.testObj.stu.classNo)
            self.testObj2.stu?.name = "uuuuuuuuu"
        })
        
    }
    
    

    func test3() {
        let requestObservable = { () -> Observable<String> in
            return Observable.create({ (observer) -> Disposable in
                // AnyObserver<Element> -> Disposable (AnyObserver<Element>事件源)
                print("模拟异步任务开始...")
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1, execute: {
                    observer.on(.next("10"))
                })
                DispatchQueue.global().asyncAfter(deadline: DispatchTime.now() + 2, execute: {
                    observer.on(.next("20"))
                    // error crash
                    //                    observer.onError(NSError(domain: "ddd", code: -1, userInfo: nil))
                })
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 3, execute: {
                    observer.on(.next("30"))
                    observer.on(.completed)
                })
                return Disposables.create()
            })
        }
//        let sig = requestObservable()
//        sig.bind(to: self.label!.rx.text)
//        
        
        // 最近的一次发送数据序列，转换为热信号，第一次订阅开始执行当前热信号
        //        let temp = requestObservable().observeOn(MainScheduler.instance).catchErrorJustReturn("出错啦").shareReplay(1)
        let temp = requestObservable().observeOn(MainScheduler.instance).catchErrorJustReturn("出错啦").shareReplayLatestWhileConnected()
        
        //        temp.subscribe { (event) in
        //            print(event,Thread.current)
        //        }
        //        temp.bind(to: self.label!.rx.text)
        //        temp.bind(to: self.label2!.rx.text)
        
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 3.5) {
            temp.subscribe { (event) in
                print(event,Thread.current)
            }
            temp.bind(to: self.label!.rx.text)
            temp.bind(to: self.label2!.rx.text)
        }
        
        //        requestObservable().bind(to: label!.rx.text)
        //        requestObservable().bind(to: label2!.rx.text)
        
    }
    
    // 多次执行网络请求，网络出错，子线程的问题
    func test4() {
        let requestObservable = { () -> Observable<String> in
            return Observable.create({ (observer) -> Disposable in
                // AnyObserver<Element> -> Disposable (AnyObserver<Element>事件源)
                print("模拟异步任务开始...")
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1, execute: {
                    observer.on(.next("10"))
                })
                DispatchQueue.global().asyncAfter(deadline: DispatchTime.now() + 2, execute: {
                    observer.on(.next("20"))
                    // error crash
//                    observer.onError(NSError(domain: "ddd", code: -1, userInfo: nil))
                })
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 3, execute: {
                    observer.on(.next("30"))
                    observer.on(.completed)
                })
                //                return Disposables.create()// NopDisposable
                return Disposables.create {
//                    print("用户自定义清理资源的block")
                }
            })
        }
        // 最近的一次发送数据序列，转换为热信号，第一次订阅开始执行当前热信号
//        let temp = requestObservable().observeOn(MainScheduler.instance).catchErrorJustReturn("出错啦").shareReplay(1)
        let temp = requestObservable().asDriver(onErrorJustReturn: "出错").asObservable()
        temp.subscribe { (event) in
            print(event,Thread.current)
        }
        temp.bind(to: self.label!.rx.text)
        temp.bind(to: self.label2!.rx.text)
        // 或者
        requestObservable().asDriver(onErrorJustReturn: "出错").drive(self.label!.rx.text)
    
        
//        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 3.5) {
//            temp.subscribe { (event) in
//                print(event,Thread.current)
//            }
//            temp.bind(to: self.label!.rx.text)
//             temp.bind(to: self.label2!.rx.text)
//        }
       
//        requestObservable().bind(to: label!.rx.text)
//        requestObservable().bind(to: label2!.rx.text)
        
    }

    deinit {
        print(self)
    }
}
