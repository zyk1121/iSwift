//
//  RXCounterViewController.swift
//  iTestProject
//
//  Created by 张元科 on 2017/12/4.
//  Copyright © 2017年 SDJG. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa

class RXCounterViewController: UIViewController {

    var label:UILabel?
    var label2:UILabel?
    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = UIColor.white
//        counter1(num: 3)
//        counter2(num: 3)
//        counter3(num: 3)
        label = UILabel()
        label?.frame = CGRect(x: 0, y: 100, width: 200, height: 40)
        label?.text = "1"
        label?.textColor = UIColor.red
        view.addSubview(label!)
        
        
        label2 = UILabel()
        label2?.frame = CGRect(x: 0, y: 300, width: 200, height: 40)
        label2?.text = "2"
        label2?.textColor = UIColor.red
        view.addSubview(label2!)
        
        test()
//
        test2()
        
    
//        test3()
    }
    
    func test3() {
        
        
//        disposeBag2 = DisposeBag()
//        Observable.just(1).subscribe { (event) in
//            print(event)
//        }.addDisposableTo(disposeBag2!)
//        for item  in 0...10000 {
//            Observable.just(1).subscribe { (event) in
//                print(event,item)
//                }.addDisposableTo(disposeBag2!)
//            disposeBag2 = DisposeBag()
//        }
//        Observable.just(2).subscribe { (event) in
//            print(event)
//            }.addDisposableTo(disposeBag2!)
    }
    

    private var myContext = 0
    var testObj =  TestObject()
    var disBag:DisposeBag?
    func test() {
        disBag = DisposeBag()
        let stu = Student()
        testObj.stu = stu
        
        testObj.rx.observe(String.self, "stu.name").subscribe { (event) in
//            print(event)
            print(Thread.current)
        }
        testObj.rx.observe(String.self, "stu.name").asObservable().bind(to: label!.rx.text).addDisposableTo(disBag!)
//        disBag = nil
//        disBag = DisposeBag()
         testObj.rx.observe(String.self, "stu.name").asObservable().bind(to: label2!.rx.text).addDisposableTo(disBag!)
//        addObserver(testObj, forKeyPath: "stu.age", options: NSKeyValueObservingOptions.new, context: &myContext)
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1.0, execute: {
//            print(self.testObj.stu.classNo)
            self.testObj.stu?.name = "123"
        })
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 3.0, execute: {
            let sss = Student()
            sss.name = "haha"
            self.testObj.stu = sss
            self.testObj.stu?.name = "abc"
//            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1.0, execute: {
//                sss.name = "hhhhh"
//            })
            DispatchQueue.global().asyncAfter(deadline: DispatchTime.now() + 1.0, execute: {
                sss.name = "hhhhh"
            })
            //            self.testObj.stu?.age = 20
        })
    }
    var testObj2 = TestObject()
    func test2()
    {
        let stu = Student()
        testObj2.stu = stu
        
//        disBag = nil
//        disBag = DisposeBag()
//        testObj2.rx.observe(String.self, "stu.name").asObservable().bind(to: label!.rx.text).addDisposableTo(disBag!)
        testObj2.rx.observeWeakly(String.self, "stu.name").asObservable().bind(to: label!.rx.text).addDisposableTo(disBag!)
        
        
//        disBag = nil
//        disBag = DisposeBag()
        testObj2.rx.observe(String.self, "stu.name").asObservable().map { (str) -> String in
            if str != nil {
                let ss = str! + "123"
                return ss
            }
            return ""
        }.bind(to: label2!.rx.text).addDisposableTo(disBag!)
        //        addObserver(testObj, forKeyPath: "stu.age", options: NSKeyValueObservingOptions.new, context: &myContext)
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1.0, execute: {
            //            print(self.testObj.stu.classNo)
            self.testObj2.stu?.name = "uuuuuuuuu"
        })

    }
    
//    func testBind(to:ObserverType) {
//        
//    }
//    
    
    
    
//    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
////        super.observeValue(forKeyPath: keyPath, of: object, change: change, context: context)
//        if context == &myContext {
//            if let newValue = change?[NSKeyValueChangeKey.newKey] {
//                print(keyPath)
//                print(newValue)
//            }
//        } else {
//            super.observeValue(forKeyPath: keyPath, of: object, change: change, context: context)
//        }
//      
//    }
    
    
//    var disposeBag = DisposeBag()

    // 计数器 😭
    func counter1(num:Int) {
        let counter:Observable<Int> = Observable.create({ (observer) -> Disposable in
            var n:Int = 1
            while true {
                observer.on(.next(n))
                n += 1
            }
            return Disposables.create()
        })
        // ----------------
        var dispose:Disposable?
        dispose = counter.subscribe({ (event) in
            if event.element! >= num {
                dispose?.dispose()
            }
            print("计数：\(event.element!)")
        })
        dispose?.addDisposableTo(disposeBag)
    }
    
    // 计数器 😭
    func counter2(num:Int) {
        let counter:Observable<Int> = Observable.create({ (observer) -> Disposable in
            var n:Int = 1
            var continueFlag:Bool = true
            let dispose = Disposables.create {
                continueFlag = false
            }
            while continueFlag {
                observer.on(.next(n))
                n += 1
            }
            return dispose
        })
        // ----------------
        var dispose:Disposable?
        dispose = counter.subscribe({ (event) in
            if event.element! >= num {
                dispose?.dispose()
            }
            print("计数：\(event.element!)")
        })
        dispose?.addDisposableTo(disposeBag)
    }
    
    // 计数器 😄
    func counter3(num:Int) {
        let counter:Observable<Int> = Observable.create({ (observer) -> Disposable in
            var n:Int = 1
            var continueFlag:Bool = true
            let dispose = Disposables.create {
                continueFlag = false
            }
            DispatchQueue.main.async {
                while continueFlag {
                    observer.on(.next(n))
                    n += 1
                }
            }
            return dispose
        })
        // ----------------
        var dispose:Disposable?
        dispose = counter.subscribe({ (event) in
            if event.element! >= num {
                dispose?.dispose()
            }
            print("计数：\(event.element!)")
        })
        dispose?.addDisposableTo(disposeBag)
    }
}

//public class SDBaseView:UIView
//{
//    var disposeBag:DisposeBag?
//}
//
//public class SDScrollView:UIScrollView
//{
//    var disposeBag:DisposeBag?
//}
//
//public class SDBaseObject:NSObject {
//    var disposeBag:DisposeBag?
//}
//
//public class SDBaseTableViewCell:UITableViewCell
//{
//    var disposeBag:DisposeBag?
//}
//
//public class SDBaseCollectionViewCell:UICollectionViewCell
//{
//    var disposeBag:DisposeBag?
//}
//
//public class SDBaseViewController:UIViewController
//{
//    var disposeBag:DisposeBag?
//    public func bindUI()
//    {
//        disposeBag = DisposeBag()
//    }
//}



//public extension UIView {
////    var disposeBag:DisposeBag?
//    public func bindUI()
//    {
////        disposeBag = nil
////        disposeBag = DisposeBag()
//    }
//}
//
//class TestView: UIView {
//    override func bindUI() {
//        super.bindUI()
//    }
//}





