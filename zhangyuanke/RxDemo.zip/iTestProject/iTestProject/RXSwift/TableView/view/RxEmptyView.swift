//
//  RxEmptyView.swift
//  iTestProject
//
//  Created by 张元科 on 2017/12/7.
//  Copyright © 2017年 SDJG. All rights reserved.
//

import UIKit
import SnapKit
import RxSwift
import RxCocoa

class RxEmptyView: UIView {

    // 定义属性
    // 图片
    public let iconView:UIImageView = {
        let view = UIImageView()
        view.image = UIImage(named: "emptyimage")
        return view
    }()
    // 文字描述
    public let contentLabel:UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = UIColor.extColorWithHex("999999", alpha: 1.0)
        label.text = "题目拉取失败，请刷新试试~"
        label.numberOfLines = 0
        return label
    }()
    // 刷新按钮
    public let refreshBtn:UIButton = {
        let button = UIButton()
        button.setTitle("点此刷新", for: .normal)
        button.setTitle("点此刷新", for: .highlighted)
        button.setTitleColor(UIColor.extColorWithHex("ce0000", alpha: 1.0), for: .normal)
        button.layer.borderWidth = 1.0
        button.layer.borderColor = UIColor.extColorWithHex("ce0000", alpha: 1.0).cgColor
        button.layer.cornerRadius = 22
        return button
    }()
    
    // init
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.extColorWithHex("ffffff", alpha: 1.0)
        setupUI()
        setNeedsUpdateConstraints()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupUI() {
        self.addSubview(iconView)
        self.addSubview(contentLabel)
        self.addSubview(refreshBtn)
    }
    
    // 布局
    override func updateConstraints() {
        iconView.snp.remakeConstraints { (make) in
            make.centerX.equalTo(self)
            make.top.equalTo(self).offset(100)
            make.width.height.equalTo(200)
        }
        contentLabel.snp.remakeConstraints { (make) in
            make.centerX.equalTo(self)
            make.top.equalTo(iconView.snp.bottom).offset(20)
        }
        refreshBtn.snp.remakeConstraints { (make) in
            make.centerX.equalTo(self)
            make.height.equalTo(44)
            make.width.equalTo(150)
            make.top.equalTo(contentLabel.snp.bottom).offset(30)
        }
        super.updateConstraints()
    }
}
