//
//  RxTableViewCell.swift
//  iTestProject
//
//  Created by 张元科 on 2017/12/7.
//  Copyright © 2017年 SDJG. All rights reserved.
//

import UIKit
import SnapKit
import RxSwift
import RxCocoa

class RxTableViewCell: UITableViewCell {

    public weak var itemData:RxTableViewModel?
    public weak var parentView:RxTableViewMainView?
    public let contentLabel:UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 17)
        label.numberOfLines = 0
        label.textColor = UIColor.extColorWithHex("666666", alpha: 1.0)
        label.text = ""
        return label
    }()
    
    public let progressLabel:UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 17)
        label.textColor = UIColor.red
        label.text = "0.0%"
        return label
    }()
    
    // init
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.backgroundColor = UIColor.extColorWithHex("eeeeee", alpha: 1.0)
        setupUI()
        bindUI()

        setNeedsUpdateConstraints()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupUI() {
        self.contentView.addSubview(self.contentLabel)
        self.contentView.addSubview(self.progressLabel)
    }
    
    override func bindUI() {
        // 清空之前的ui绑定
        super.bindUI()
        // 绑定ui数据
        if let item = itemData {
            // 使用 disposeBagForBinding
//            self.progressLabel.text = "\(item.progress)"
            item.rx.observe(Float.self, "progress").asObservable().map({ (value) -> String in
                if value != nil {
                    return "\(value!)%"
                }
                return "0.0%"
            }).bind(to: self.progressLabel.rx.text).addDisposableTo(disposeBagForBinding)
        }
    }

    func setupContentInfo(info:RxTableViewModel) {
        if itemData != nil && itemData! == info {
            return
        }
        self.itemData = info
        
        self.contentLabel.text = info.content
        self.contentLabel.sizeToFit()
        if let index = self.parentView?.mainTableView.indexPath(for: self) {
            self.parentView?.mainTableView.reloadRows(at: [index], with: UITableViewRowAnimation.automatic)
        }
        // 重新绑定ui
        bindUI()
        updateConstraintsIfNeeded()
    }
    
    override func updateConstraints() {
        self.progressLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.contentView)
            make.width.equalTo(60)
            make.right.equalTo(self.contentView).offset(-20)
        }
        
        self.contentLabel.sizeToFit()
        self.contentLabel.snp.remakeConstraints { (make) in
            make.left.top.equalTo(self.contentView).offset(20)
            make.bottom.equalTo(self.contentView).offset(-20)
            make.right.equalTo(self.progressLabel.snp.left).offset(-20)
        }
        super.updateConstraints()
    }
}
