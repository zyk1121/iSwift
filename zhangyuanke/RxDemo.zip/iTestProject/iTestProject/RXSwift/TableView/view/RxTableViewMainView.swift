//
//  RxTableViewMainView.swift
//  iTestProject
//
//  Created by 张元科 on 2017/12/7.
//  Copyright © 2017年 SDJG. All rights reserved.
//

import UIKit
import SnapKit
import RxSwift
import RxCocoa

class RxTableViewMainView: UIView {

    public var tableViewDatas:[RxTableViewModel] = []
    // 定义属性
    public let mainTableView:UITableView = {
        let tableView = UITableView(frame: CGRect.zero, style: UITableViewStyle.plain)
        tableView.estimatedRowHeight = 50
        tableView.tableFooterView = UIView()
        tableView.separatorStyle = .none
        tableView.showsHorizontalScrollIndicator = false
        tableView.showsVerticalScrollIndicator = false
        tableView.backgroundColor = UIColor.extColorWithHex("ffffff", alpha: 1.0)
        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.register(RxTableViewCell.classForCoder(), forCellReuseIdentifier: "RxTableViewCell")
        tableView.translatesAutoresizingMaskIntoConstraints = false
        return tableView
    }()
    
    // init
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.white
        setupUI()
        setNeedsUpdateConstraints()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupUI() {
        mainTableView.dataSource = self
        mainTableView.delegate = self
        self.addSubview(self.mainTableView)
    }
    
    func setupContentData(data:[RxTableViewModel]) {
        tableViewDatas = data
        self.mainTableView.reloadData()
        
        // 测试数据更新
        self.testupdateData()
    }
    
    func testupdateData()
    {
        for item in tableViewDatas {
            if item.progress > 100 {
                return
            }
            item.progress += 1.0
        }
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1.0) { 
            self.testupdateData()
        }
    }
    
    // 布局
    override func updateConstraints() {
        mainTableView.snp.remakeConstraints { (make) in
            make.left.right.bottom.equalTo(self)
            make.top.equalTo(self)
        }
        super.updateConstraints()
    }
}

extension RxTableViewMainView:UITableViewDelegate,UITableViewDataSource,UIScrollViewDelegate {
    
    public func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableViewDatas.count
    }
    
    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "RxTableViewCell", for: indexPath)
        if let rxCell = cell as? RxTableViewCell {
            rxCell.parentView = self
            rxCell.setupContentInfo(info: tableViewDatas[indexPath.row])
            rxCell.setNeedsUpdateConstraints()
            rxCell.selectionStyle = .none
        }
        return cell
    }
}
