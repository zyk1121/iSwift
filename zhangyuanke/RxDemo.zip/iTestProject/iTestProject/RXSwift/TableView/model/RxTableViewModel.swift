//
//  RxTableViewModel.swift
//  iTestProject
//
//  Created by 张元科 on 2017/12/7.
//  Copyright © 2017年 SDJG. All rights reserved.
//

import UIKit
import ObjectMapper

/* 数据实体 */
class RxTableViewModel: NSObject, Mappable {
    
    var content:String = ""
    dynamic var progress:Float = 0.0
    
    // 行高
    var cellHeight:CGFloat = -1.0
    
    class func createObj()->RxTableViewModel? {
        let obj = Mapper<RxTableViewModel>().map(JSON: [:])
        return obj
    }
    
    required init?(map: Map) {
        
    }
    func mapping(map: Map) {
        content <- map["content"]
        progress <- map["progress"]
    }
}
