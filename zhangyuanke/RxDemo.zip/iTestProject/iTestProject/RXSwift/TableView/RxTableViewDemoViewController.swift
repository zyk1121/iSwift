//
//  RxTableViewDemoViewController.swift
//  iTestProject
//
//  Created by 张元科 on 2017/12/7.
//  Copyright © 2017年 SDJG. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa

class RxTableViewDemoViewController: UIViewController {

    let mainView        = RxTableViewMainView()
    let mainViewModel   = RxTableViewViewModel()
    let emptyView       = RxEmptyView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        setupUI()
        bindUI()
        view.setNeedsUpdateConstraints()
        startLoadData()
    }
    
    func setupUI()
    {
        view.addSubview(mainView)
        view.addSubview(emptyView)
        emptyView.isHidden = true
    }
    
    override func bindUI() {
        // 空页面按钮点击
        emptyView.refreshBtn.rx.controlEvent(UIControlEvents.touchUpInside).asObservable().subscribe {[weak self] (event) in
            self?.hideExamEmptyView()
            self?.startLoadData()
        }.addDisposableTo(disposeBag)
    }
    
    func isNoNetwork()->Bool {
        return false
    }
    
    func startLoadData()
    {
        if isNoNetwork() {
            showExamEmptyView()
            // toast 提示用户
            return
        }
        loadData()
    }
    
    func loadMoreData()
    {
        if isNoNetwork() {
            // toast 提示用户
            return
        }
        
        // page + 1，加载更多数据
        loadData()
    }
    
    func showExamEmptyView() {
        self.mainView.isHidden = true
        self.emptyView.isHidden = false
    }
    
    func hideExamEmptyView() {
        self.mainView.isHidden = false
        self.emptyView.isHidden = true
    }
    
    // MARK:Constraints
    override func updateViewConstraints() {
        super.updateViewConstraints()
        mainView.snp.remakeConstraints { (make) in
            make.left.right.bottom.equalTo(self.view)
            make.top.equalTo(self.view).offset(0)
        }
        emptyView.snp.remakeConstraints { (make) in
            make.left.right.bottom.equalTo(self.view)
            make.top.equalTo(self.view).offset(0)
        }
    }
}

extension RxTableViewDemoViewController {
    func loadData()
    {
//        ProgressHUDManager.showLoadingWithImages("正在加载...", maskType: .clear)
        let param = [
            "studentId":"12345",
            "studentName":"yuanke",
            "paperId":234,
            "examId": 456] as [String : Any]
        
        self.mainViewModel.fetchStudentTakeExam(param:param).subscribe(onNext: {[weak self] (datas) in
                self?.mainView.setupContentData(data: datas)
            }, onError: {[weak self] (error) in
//                ProgressHUDManager.dismiss()
                self?.showExamEmptyView()
            }, onCompleted: {
//                ProgressHUDManager.dismiss()
        }, onDisposed: nil).addDisposableTo(disposeBag)
    }
}
