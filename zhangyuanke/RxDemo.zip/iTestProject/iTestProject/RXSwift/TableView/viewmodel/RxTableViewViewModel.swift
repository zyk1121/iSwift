//
//  RxTableViewViewModel.swift
//  iTestProject
//
//  Created by 张元科 on 2017/12/7.
//  Copyright © 2017年 SDJG. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa

class RxTableViewViewModel: NSObject {
    // 抓取网络数据
    func fetchStudentTakeExam(param: [String: Any]) -> Observable<[RxTableViewModel]> {
        return Observable.create({ (observer) -> Disposable in
            self.requestExamData(module:"/tExam", action:"/studentTakeExam", param: param, completion: { (result, error) in
                if error != nil {
                    observer.onError(error!)
                } else {
                    // 获取数据
                    if let objs = result as? [RxTableViewModel] {
                        observer.onNext(objs)
                        observer.onCompleted()
                    } else {
                        let err = NSError(domain: "ddd", code: -1, userInfo: nil)
                        observer.onError(err)
                    }
                }
            })
            return Disposables.create()
        })
    }
}

extension RxTableViewViewModel {
    // request
    func requestExamData(module:String = "/tExam", action:String, param: [String: Any], completion:((_ result:Any?,_ error:Error?)->Void)?) {
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1.0) {
            
            var arrs:[RxTableViewModel] = []
            if let obj = RxTableViewModel.createObj() {
                obj.content = "测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据1"
                obj.progress = 1.0
                arrs.append(obj)
            }
            
            if let obj = RxTableViewModel.createObj() {
                obj.content = "测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据2"
                obj.progress = 2.0
                arrs.append(obj)
            }
            if let obj = RxTableViewModel.createObj() {
                obj.content = "测试数据测试数据3"
                obj.progress = 3.0
                arrs.append(obj)
            }
            if let obj = RxTableViewModel.createObj() {
                obj.content = "测试数据测试数据测数据测试数据测试数据测试数据测试数据测试数据4"
                obj.progress = 4.0
                arrs.append(obj)
            }
            if let obj = RxTableViewModel.createObj() {
                obj.content = "测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据5"
                obj.progress = 5.0
                arrs.append(obj)
            }
            if let obj = RxTableViewModel.createObj() {
                obj.content = "测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据6"
                obj.progress = 6.0
                arrs.append(obj)
            }
            
            if let obj = RxTableViewModel.createObj() {
                obj.content = "测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据7"
                obj.progress = 7.0
                arrs.append(obj)
            }
            
            if let obj = RxTableViewModel.createObj() {
                obj.content = "测试数据测试数据8"
                obj.progress = 8.0
                arrs.append(obj)
            }
            if let obj = RxTableViewModel.createObj() {
                obj.content = "测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据9"
                obj.progress = 9.0
                arrs.append(obj)
            }
            if let obj = RxTableViewModel.createObj() {
                obj.content = "测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据10"
                obj.progress = 10.0
                arrs.append(obj)
            }
            
            if completion != nil {
                completion!(arrs, nil)
            }
        }
    }
}
