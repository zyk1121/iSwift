//
//  RXMVVMModel.swift
//  iTestProject
//
//  Created by 张元科 on 2017/7/12.
//  Copyright © 2017年 SDJG. All rights reserved.
//

import UIKit

class UserModel: NSObject {
    var userName:String
    var password:String
    var age:Int = 0
    var isLogin:Bool = false
    
    override init() {
        userName = ""
        password = ""
        
        super.init()
    }
    
}

class UserModel2: NSObject {
    var userName:String
    var password:String
    var age:Int = 0
    var isLogin:Bool = false
    
    override init() {
        userName = ""
        password = ""
        
        super.init()
    }
    
}


class UserModel3: NSObject {
    var userName:String
    var password:String
    var age:Int = 0
    var isLogin:Bool = false
    
    override init() {
        userName = ""
        password = ""
        
        super.init()
    }
    
}

