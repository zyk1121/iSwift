//
//  ViewController.swift
//  iTestProject
//
//  Created by 张元科 on 2017/7/1.
//  Copyright © 2017年 SDJG. All rights reserved.
//

import UIKit

import RxSwift

class ViewController: UIViewController {

    var tableViewKeys:[String] = []
    var tableViewData:[String:String] = [:]
    
    var tableView:UITableView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        setupData()
        setupUI()
    }
    
    func setupData() {
        tableViewKeys = ["RxSwift基础","冷热信号","统一监听方法","绑定UI","使用实战","线程调度","内存管理","实战-计数器","bindto","MVVM实战"]

        tableViewData = ["RxSwift基础":"sdjg://router/rx/base",
                         "冷热信号":"sdjg://router/rx/coldhot",
                         "统一监听方法":"sdjg://router/rx/observe",
                         "绑定UI":"sdjg://router/rx/bindui",
                         "使用实战":"sdjg://router/rx/use",
                         "线程调度":"sdjg://router/rx/schedulers",
                         "内存管理":"sdjg://router/rx/memory",
                         "实战-计数器":"sdjg://router/rx/counter",
                         "bindto":"sdjg://router/rx/newbinding",
                         "MVVM实战":"sdjg://router/rx/tableviewdemo"]
    }
    
    func setupUI()
    {
        tableView = UITableView(frame: view.frame, style: .plain)
        tableView?.register(UITableViewCell.classForCoder(), forCellReuseIdentifier: "test")
        tableView?.dataSource = self
        tableView?.delegate = self
        tableView?.rowHeight = 70
        tableView?.tableFooterView = UIView()
        view.addSubview(tableView!)
    }
}

extension ViewController : UITableViewDataSource,UITableViewDelegate
{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableViewData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "test", for: indexPath)
        cell.textLabel?.text = tableViewKeys[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let key = tableViewKeys[indexPath.row]
        let value = tableViewData[key]
//        SDJGUrlRouterManager.router(sourceVC: self, toURL: NSURL(string:value!)!)
        SDJGUrlRouterManager.router(sourceVC: self, toURL: NSURL(string:value!)!, transferType: .push, userInfo: nil) { (vc, error) in
            vc?.title = key
        }
    }
}




extension UIColor {
    
    public final class func level(level: AnyObject) -> UIColor {
        let colorValue = NSString(string: "\(level)").intValue
        let colorText = colorValue <= 5 ? "6bbfff" : (colorValue <= 10 ? "fdb829" : "ff9865")
        return UIColor.extColorWithHex(colorText, alpha: 1)
    }
    
    
    public final class func extRGBA(red : CGFloat , green : CGFloat , blue : CGFloat , alpha : CGFloat)-> UIColor{
        
        return UIColor.init(red: red/255.0, green: green/255.0, blue: blue/255.0, alpha: alpha)
        
    }
    
    
    public final class func extColorWithHex(_ hex : String, alpha:CGFloat) -> UIColor{
        var hexColor = hex
        
        hexColor = hexColor.replacingOccurrences(of: " ", with: "")
        if(hexColor.hasPrefix("#")){
            hexColor = hexColor.substring(from: hexColor.index(hexColor.startIndex, offsetBy: 1))
        }else{
            
        }
        
        
        let rStr = hexColor.substring(with: hexColor.startIndex ..< hexColor.index(hexColor.startIndex, offsetBy: 2))
        let gStr = hexColor.substring(with: hexColor.index(hexColor.startIndex, offsetBy: 2) ..< hexColor.index(hexColor.startIndex, offsetBy: 4))
        let bStr = hexColor.substring(with: hexColor.index(hexColor.startIndex, offsetBy: 4) ..< hexColor.index(hexColor.startIndex, offsetBy: 6))
        var r = uint()
        var g = uint()
        var b = uint()
        
        Scanner.init(string: rStr).scanHexInt32(&r)
        Scanner.init(string: gStr).scanHexInt32(&g)
        Scanner.init(string: bStr).scanHexInt32(&b)
        
        let color : UIColor = UIColor.init(red: CGFloat(r)/255.0, green: CGFloat(g)/255.0, blue: CGFloat(b)/255.0, alpha: alpha)
        return color;
    }
    
}




