//
//  ViewController.swift
//  TestLibDemo
//
//  Created by 张元科 on 2018/4/16.
//  Copyright © 2018年 SDJG. All rights reserved.
//

import UIKit
import TestStaticSwiftLib
import TestDynamicSwiftLib
import TestDynamicOCLib

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // 静态库.a测试-OC
        let testStaticLib = TestStaticLib()
        testStaticLib.run()
        
        // 静态库.framework测试-OC
        let testStaticFramework = TestStaticFramework()
        testStaticFramework.run()
        
        // 动态库.framework测试-OC
        let testDynamicOCLib = TestDynamicOCLib()
        testDynamicOCLib.run()
        
        // 静态库.framework测试-swift
        let testStaticSwiftLib = TestStaticSwiftLib()
        testStaticSwiftLib.run()
        
        // 动态库.framewor测试-swift
        let testDynamicSwiftLib = TestDynamicSwiftLib()
        testDynamicSwiftLib.run()
        
    }
}

