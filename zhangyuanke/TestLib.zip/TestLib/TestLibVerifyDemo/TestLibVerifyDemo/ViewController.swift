//
//  ViewController.swift
//  TestLibVerifyDemo
//
//  Created by 张元科 on 2018/4/16.
//  Copyright © 2018年 SDJG. All rights reserved.
//

import UIKit
import TestDynamicSwiftLib
import TestStaticSwiftLib

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        print("拷贝framework到TestLibVerifyDemo本地目录，并拖动到项目中以验证是动态库还是静态库,如果可以直接run成功说明是静态库，动态库需要通过Embeded binaries的方式添加。")
        let test = TestStaticSwiftLib()
        test.run()
    }
}

