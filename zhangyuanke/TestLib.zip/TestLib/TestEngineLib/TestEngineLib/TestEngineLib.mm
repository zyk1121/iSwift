//
//  TestEngineLib.m
//  TestEngineLib
//
//  Created by 张元科 on 2018/4/17.
//  Copyright © 2018年 SDJG. All rights reserved.
//

#import "TestEngineLib.h"
#import "TestEngineCpp.hpp"

@implementation TestEngineLib
- (void)run
{
    NSLog(@"TestEngineLib run...");
    // 调用C++引擎库
    NSLog(@"调用C++引擎库:");
    TestEngineCpp *cpp = new TestEngineCpp;
    cpp->testRun();
}
@end
