//
//  TestEngineCpp.hpp
//  TestEngineLib
//
//  Created by 张元科 on 2018/4/17.
//  Copyright © 2018年 SDJG. All rights reserved.
//

#ifndef TestEngineCpp_hpp
#define TestEngineCpp_hpp

#include <stdio.h>

class TestEngineCpp {
public:
    void testRun();
};

#endif /* TestEngineCpp_hpp */
