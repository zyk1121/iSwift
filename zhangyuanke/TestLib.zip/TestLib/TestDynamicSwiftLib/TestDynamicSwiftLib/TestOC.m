//
//  TestOC.m
//  TestDynamicSwiftLib
//
//  Created by 张元科 on 2018/4/16.
//  Copyright © 2018年 SDJG. All rights reserved.
//

#import "TestOC.h"

@implementation TestOC
- (void)run
{
    NSLog(@"TestDynamicSwiftLib TestOC run...");
}
@end
