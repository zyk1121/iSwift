//
//  HelloWorldServerManager.swift
//  HelloWorldPrefect
//
//  Created by 张元科 on 2018/5/5.
//

import Foundation
import PerfectLib
import PerfectHTTP
import PerfectHTTPServer

open class HelloWorldServerManager {
    fileprivate var server: HTTPServer
    // http://localhost:8888/helloapi/
    internal init(root: String, port: UInt16) {
        server = HTTPServer.init()                          //创建HTTPServer服务器
        var routes = Routes.init(baseUri: "/helloapi")           //创建路由器
        configure(routes: &routes)                          //注册路由
        server.addRoutes(routes)                            //路由添加进服务
        server.serverPort = port                            //端口
        server.documentRoot = root                          //根目录
        server.setResponseFilters([(Filter404(), .high)])   //404过滤
    }
    
    //MARK: 开启服务
    open func startServer() {
        do {
            print("启动HTTP服务器")
            try server.start()
        } catch PerfectError.networkError(let err, let msg) {
            print("网络出现错误：\(err) \(msg)")
        } catch {
            print("网络未知错误")
        }
        
    }
    
    //MARK: 注册路由
    fileprivate func configure(routes: inout Routes) {
        // 添加GET接口,请求方式,路径
        routes.add(method: .get, uri: "/testget") { (request, response) in
            response.setHeader( .contentType, value: "application/json")
            
            let jsonDic = ["hello": "world get"]
            let jsonString = self.baseResponseBodyJSONData(status: 200, message: "成功", data: jsonDic)
            response.setBody(string: jsonString)                           //响应体
            response.status = .ok
            response.completed()                                           //响应
        }
        
        // 添加POST接口,请求方式,路径
        routes.add(method: .post, uri: "/testpost") { (request, response) in
            response.setHeader( .contentType, value: "application/json")
            let jsonDic = ["hello": "world post" + request.queryParams.description]
            let jsonString = self.baseResponseBodyJSONData(status: 200, message: "成功", data: jsonDic)
            response.setBody(string: jsonString)                           //响应体
            response.status = .ok
            response.completed()                                           //响应
        }
    }
    
    //MARK: 通用响应格式
    func baseResponseBodyJSONData(status: Int, message: String, data: Any!) -> String {
        var result = Dictionary<String, Any>()
        result.updateValue(status, forKey: "status")
        result.updateValue(message, forKey: "message")
        if (data != nil) {
            result.updateValue(data, forKey: "data")
        }else{
            result.updateValue("", forKey: "data")
        }
        guard let jsonString = try? result.jsonEncodedString() else {
            return ""
        }
        return jsonString
    }
    
    //MARK: 404过滤
    struct Filter404: HTTPResponseFilter {
        
        func filterBody(response: HTTPResponse, callback: (HTTPResponseFilterResult) -> ()) {
            callback(.continue)
        }
        
        func filterHeaders(response: HTTPResponse, callback: (HTTPResponseFilterResult) -> ()) {
            if case .notFound = response.status {
                response.setHeader( .contentType, value: "application/json")
                response.setBody(string: "404 文件\(response.request.path)不存在。")
                response.setHeader(.contentLength, value: "\(response.bodyBytes.count)")
                callback(.done)
                
            } else {
                callback(.continue)
            }
        }
    }
}
