import PerfectLib
import PerfectHTTP
import PerfectHTTPServer

//let networkServer = HelloWorldServerManager(root: "./webroot", port: 8888)
//networkServer.startServer()

let networkServer = HelloWorldServerManager(root: "/Users/zhangyuanke/webroot", port: 8888)
networkServer.startServer()
