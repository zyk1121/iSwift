// 软件包管理
import PackageDescription
let versions = Version(0,0,0)..<Version(10,0,0)
let urls = [
    "https://github.com/PerfectlySoft/Perfect-HTTPServer.git"      //HTTP服务
]

let package = Package(
    name: "HelloWorldPrefect",
    targets: [],
    dependencies: urls.map { .Package(url: $0, versions: versions) }
)
